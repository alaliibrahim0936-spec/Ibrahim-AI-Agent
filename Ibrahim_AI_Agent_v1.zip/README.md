# Ibrahim AI Agent v1

Android + FastAPI starter for a personal AI agent.

Architecture:
Android app -> FastAPI server -> OpenAI Responses API

Important: keep the API key on the server, never inside the Android APK.

Server:
1. cd server
2. pip install -r requirements.txt
3. copy .env.example to .env and add OPENAI_API_KEY
4. uvicorn main:app --host 0.0.0.0 --port 8000

Android:
Open the android folder in Android Studio and run it. Change BASE_URL in MainActivity.kt to your server address.

v1 includes text chat and voice input/output foundation. Later stages will add web search, files, contacts, calls, messaging, reminders, and confirmation gates for external actions.
