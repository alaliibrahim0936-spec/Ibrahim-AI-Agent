package com.ibrahim.aiagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.Locale

private const val BASE_URL = "http://10.0.2.2:8000"

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var voiceText: ((String) -> Unit)? = null

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            micPermission.launch(Manifest.permission.RECORD_AUDIO)

        setContent {
            AgentScreen(
                onSpeak = { startVoiceInput { voiceText = it } },
                initialVoice = voiceText,
                onReply = { speak(it) }
            )
        }
    }

    private fun startVoiceInput(result: (String) -> Unit) {
        voiceText = result
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
        }
        startActivityForResult(i, 700)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 700 && resultCode == RESULT_OK)
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { voiceText?.invoke(it) }
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun AgentScreen(onSpeak: () -> Unit, initialVoice: String?, onReply: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<Pair<Boolean,String>>() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(initialVoice) { if (!initialVoice.isNullOrBlank()) input = initialVoice }

    fun send() {
        val msg=input.trim(); if (msg.isEmpty() || busy) return
        messages.add(true to msg); input=""; busy=true
        scope.launch(Dispatchers.IO) {
            val body=JSONObject().put("message",msg).toString().toRequestBody("application/json".toMediaType())
            val req=Request.Builder().url("$BASE_URL/chat").post(body).build()
            val out=runCatching { OkHttpClient().newCall(req).execute().use { r ->
                if(!r.isSuccessful) error(r.body?.string() ?: "Server error")
                JSONObject(r.body!!.string()).getString("reply")
            }}.getOrElse { "خطأ: ${it.message}" }
            withContext(Dispatchers.Main) { messages.add(false to out); busy=false; onReply(out) }
        }
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("Ibrahim AI Agent", style=MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(messages) { (mine,t) -> Surface(tonalElevation=2.dp) {
                    Text((if(mine) "أنت: " else "الوكيل: ")+t, Modifier.padding(12.dp))
                }}
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(input, { input=it }, Modifier.weight(1f), placeholder={Text("اكتب أمرك...")})
                Button(onClick=onSpeak) { Text("🎤") }
                Button(onClick={::send}, enabled=!busy) { Text("إرسال") }
            }
        }
    }
}
