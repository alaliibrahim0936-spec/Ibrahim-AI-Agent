import os, httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Ibrahim AI Agent API")
API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")

SYSTEM = '''You are Ibrahim's personal AI agent.
Speak Arabic by default unless the user asks for another language.
Be practical and concise. Never claim an external action was completed unless a tool actually completed it.
For sending messages, calls, purchases, deletion, or other external/irreversible actions, require explicit confirmation.
'''

class ChatRequest(BaseModel):
    message: str

@app.get("/health")
async def health():
    return {"ok": True}

@app.post("/chat")
async def chat(req: ChatRequest):
    if not API_KEY:
        raise HTTPException(500, "OPENAI_API_KEY is not configured")
    payload = {"model": MODEL, "instructions": SYSTEM, "input": req.message}
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post("https://api.openai.com/v1/responses", headers=headers, json=payload)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text)
    data = r.json()
    reply = data.get("output_text")
    if not reply:
        parts = []
        for item in data.get("output", []):
            for c in item.get("content", []):
                if c.get("type") in ("output_text", "text") and c.get("text"):
                    parts.append(c["text"])
        reply = "\n".join(parts).strip()
    return {"reply": reply or "لم أستطع استخراج الرد."}
